Siesta.Harness.Browser.ExtJS.configure({
  title: 'ExtJS Application',
  loaderPath: { 'ExtJS' : '/assets/extjs/app' },

  preload : [
    "/assets/extjs/resources/css/ext-all.css",
    "/assets/extjs/ext-all-debug.js"
  ]
});
